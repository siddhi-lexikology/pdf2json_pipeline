import os
import time
import json
import re
from io import BytesIO

from PIL import Image
import pytesseract
import google.generativeai as genai

# ============================
# CONFIG (Docker-friendly)
# ============================

API_KEY = os.environ.get("GEMINI_API_KEY")
if not API_KEY:
    raise RuntimeError("GEMINI_API_KEY environment variable is not set")

# These will be mounted by Docker:
# /app/data/input → contains exam image folders
# /app/data/output → JSON outputs
ROOT_IMAGE_DIR = os.environ.get("ROOT_IMAGE_DIR", "/app/data/input")
OUTPUT_DIR = os.environ.get("OUTPUT_DIR", "/app/data/output")

MODEL_NAME = "gemini-2.0-flash"
USE_OCR = True
REQUEST_DELAY = 1.0
MAX_RETRIES = 2
MAX_TOKENS = 3500

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel(MODEL_NAME)
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================
# DIFFICULTY DETECTOR
# ============================

def detect_difficulty(question_text: str) -> str:
    if not question_text:
        return "medium"

    text = question_text.lower()
    easy_words = ["simple", "direct", "basic", "formula", "straight", "easy"]
    hard_words = ["tough", "complex", "lengthy", "advanced", "difficult", "tricky"]

    if any(w in text for w in hard_words):
        return "hard"
    if any(w in text for w in easy_words):
        return "easy"
    return "medium"


# ============================
# ANSWER KEY PARSER
# ============================

def extract_answer_key_from_last_page(image_path: str) -> dict:
    mapping = {}
    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)

        text = text.replace("mathongo", "").replace("MathonGo", "")

        pattern = r"(\d+)\s*[\.\-]?\s*\(\s*([0-9]+)\s*\)"
        for qno, ans in re.findall(pattern, text):
            mapping[int(qno)] = ans

    except Exception as e:
        print("⚠️ Could not extract answer key:", e)

    print(f"Answer key extracted for {len(mapping)} questions.")
    return mapping


# ============================
# IMAGE UTILS
# ============================

def resize_image(img: Image.Image, max_side: int = 1100):
    img = img.copy()
    img.thumbnail((max_side, max_side), Image.LANCZOS)
    return img

def img_to_bytes(img: Image.Image) -> bytes:
    buf = BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()

def ocr_image(img: Image.Image) -> str:
    if not USE_OCR:
        return ""
    return pytesseract.image_to_string(img).strip()


# ============================
# PROMPT BUILDER
# ============================

def build_prompt(label: str, ocr_text: str) -> str:
    if not ocr_text:
        ocr_text = "No reliable OCR text found."

    if len(ocr_text) > 2000:
        ocr_text = ocr_text[:2000] + " ..."

    return f"""
You extract JEE Main questions from a page.

OCR text:
\"\"\"{ocr_text}\"\"\"

Return ONLY valid JSON in this structure:

{{
  "Physics":   {{"questions": []}},
  "Chemistry": {{"questions": []}},
  "Maths":     {{"questions": []}}
}}

Each question object MUST be:

{{
  "question_number": <integer>,
  "question_text": "<full text>",
  "options": {{
    "a": "...",
    "b": "...",
    "c": "...",
    "d": "..."
  }},
  "correct_option": "<a/b/c/d for MCQ, or null if unknown or NAT>",
  "explanation": "",
  "topic": "<topic>",
  "difficulty": "<Easy|Medium|Hard>",
  "has_image": <true|false>,
  "image_description": "<short English description (10–20 words)>"
}}

Rules:
- Use true printed question_number.
- Do NOT guess answers.
- NAT questions → correct_option = null.
- Return ALWAYS valid JSON.
Page: {label}
"""


# ============================
# NORMALISERS
# ============================

def _to_int_or_zero(x):
    try:
        return int(x)
    except:
        return 0

def normalise_question(q: dict) -> dict:
    qno = _to_int_or_zero(
        q.get("qno", q.get("question_number", 0))
    )

    question_text = q.get("question", q.get("question_text", ""))

    options = q.get("options", {})
    if not isinstance(options, dict) or all(v in ("", None, "...") for v in options.values()):
        options = {}

    q_type = "NAT" if not options else "MCQ"

    correct_option = q.get("correct_option", q.get("answer"))
    if isinstance(correct_option, str):
        correct_option = correct_option.strip()
        if correct_option == "":
            correct_option = None

    diff_internal = detect_difficulty(question_text)
    difficulty = diff_internal.capitalize()

    return {
        "question_number": qno,
        "question_text": question_text,
        "options": {k: ("" if v is None else str(v)) for k, v in options.items()},
        "correct_option": correct_option,
        "explanation": "",
        "topic": q.get("topic", ""),
        "difficulty": difficulty,
        "has_image": bool(q.get("has_image", False)),
        "image_description": q.get("image_description", "")
    }


def normalise_subject_block(page_json: dict, subject: str):
    block = page_json.get(subject, {})
    questions = block.get("questions", [])
    return [normalise_question(q) for q in questions if q.get("question") or q.get("question_text")]


def simple_json_repair(raw: str) -> str:
    start = raw.find("{")
    end = raw.rfind("}")
    if start != -1 and end != -1 and end > start:
        raw = raw[start:end + 1]

    raw = re.sub(r",\s*([}\]])", r"\1", raw)
    raw = re.sub(r"[\x00-\x1F]+", " ", raw)

    return raw


# ============================
# PROCESS ONE PAGE
# ============================

def process_page(img_path: str):
    print(f"→ Processing {os.path.basename(img_path)}")

    img = resize_image(Image.open(img_path))
    ocr_text = ocr_image(img)
    prompt = build_prompt(os.path.basename(img_path), ocr_text)

    content = [prompt, {"mime_type": "image/png", "data": img_to_bytes(img)}]

    cfg = genai.types.GenerationConfig(
        response_mime_type="application/json",
        temperature=0.1,
        max_output_tokens=MAX_TOKENS
    )

    for attempt in range(MAX_RETRIES):
        try:
            resp = model.generate_content(content, generation_config=cfg)
            raw = (resp.text or "").strip()
            if not raw:
                raise ValueError("Empty response")

            try:
                data = json.loads(raw)
            except:
                data = json.loads(simple_json_repair(raw))

            return {
                "Physics": normalise_subject_block(data, "Physics"),
                "Chemistry": normalise_subject_block(data, "Chemistry"),
                "Maths": normalise_subject_block(data, "Maths")
            }

        except Exception as e:
            print(f"Retry {attempt+1}/{MAX_RETRIES}: {e}")
            time.sleep(2 ** attempt)

    print("❌ FAILED:", img_path)
    return None


# ============================
# PROCESS ONE PAPER
# ============================

def process_images_folder(folder_path: str, output_json_path: str):
    print("\n📄 Folder:", folder_path)

    images = sorted(
        [f for f in os.listdir(folder_path) if f.lower().endswith((".png", ".jpg", ".jpeg"))],
        key=lambda x: int("".join(filter(str.isdigit, x)) or 0)
    )

    if not images:
        print("⚠️ No images found.")
        return

    global ANSWER_KEY
    ANSWER_KEY = extract_answer_key_from_last_page(os.path.join(folder_path, images[-1]))

    final = {"Physics": {"questions": []}, "Chemistry": {"questions": []}, "Maths": {"questions": []}}

    for img in images:
        page_json = process_page(os.path.join(folder_path, img))
        time.sleep(REQUEST_DELAY)
        if not page_json:
            continue

        for s in ["Physics", "Chemistry", "Maths"]:
            final[s]["questions"].extend(page_json[s])

    # Autofill missing answers
    for s in final:
        for q in final[s]["questions"]:
            qno = q["question_number"]
            if q.get("correct_option") is None and qno in ANSWER_KEY:
                q["correct_option"] = ANSWER_KEY[qno]

    # Drop invalid qno
    for s in final:
        final[s]["questions"] = [q for q in final[s]["questions"] if q["question_number"] > 0]

    # Sort
    for s in final:
        final[s]["questions"].sort(key=lambda x: x["question_number"])

    with open(output_json_path, "w", encoding="utf-8") as f:
        json.dump(final, f, indent=2, ensure_ascii=False)

    print("✅ Saved:", output_json_path)


# ============================
# BULK PROCESSOR
# ============================

def process_all_papers(root_dir, output_dir):
    print("\n🏁 Bulk processing:", root_dir)

    for entry in os.listdir(root_dir):
        folder_path = os.path.join(root_dir, entry)
        if not os.path.isdir(folder_path):
            continue

        has_images = any(f.lower().endswith((".png", ".jpg", ".jpeg")) for f in os.listdir(folder_path))
        if not has_images:
            continue

        out = os.path.join(output_dir, f"{entry}.json")
        print("\n==============================")
        print("📂 Paper:", entry)
        print("==============================")
        process_images_folder(folder_path, out)


# ============================
# MAIN
# ============================

if __name__ == "__main__":
    start = time.time()
    process_all_papers(ROOT_IMAGE_DIR, OUTPUT_DIR)
    print("\n🎉 Done in", round(time.time() - start, 2), "sec")
